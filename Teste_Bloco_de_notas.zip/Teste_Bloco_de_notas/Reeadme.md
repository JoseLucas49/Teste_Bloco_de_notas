# Bloco de Notas Simples

Este é um projeto de uma aplicação simples de Bloco de Notas implementada em Python, com testes unitários automatizados usando Pytest. A aplicação permite criar, listar, editar, excluir e conectar notas, com validações específicas para as regras de negócio.

## Requisitos
- Python 3.8+
- Pytest (`pip install pytest`)
- Pytest-cov (`pip install pytest-cov`) para cobertura de testes
- UUID (biblioteca padrão do Python)

## Como Executar a Aplicação
1. Clone o repositório ou descompacte a pasta `bloco-de-notas`:
   ```bash
   cd bloco-de-notas