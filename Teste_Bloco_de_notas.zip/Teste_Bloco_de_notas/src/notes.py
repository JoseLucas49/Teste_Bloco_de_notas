import uuid

class Note:
    VALID_CATEGORIES = {"Trabalho", "Pessoal", "Estudos", "Histórias", "Projetos Futuros"}

    def __init__(self, title, content, category):
        if not title or len(title) > 100:
            raise ValueError("O título deve ser não vazio e ter até 100 caracteres.")
        if category not in self.VALID_CATEGORIES:
            raise ValueError("Categoria inválida. Use: Trabalho, Pessoal, Estudos, Histórias ou Projetos Futuros.")
        if len(content) > 500:
            raise ValueError("O conteúdo deve ter até 500 caracteres.")
        
        self.id = str(uuid.uuid4())
        self.title = title
        self.content = content
        self.category = category
        self.related_note_id = None

class NotesApp:
    def __init__(self):
        self.notes = []

    def create_note(self, title, content, category):
        note = Note(title, content, category)
        self.notes.append(note)
        return note.id

    def list_notes(self):
        return self.notes

    def edit_note(self, note_id, title=None, content=None, category=None):
        note = self._find_note(note_id)
        if not note:
            raise ValueError("Nota não encontrada.")
        
        if title is not None:
            if not title or len(title) > 100:
                raise ValueError("O título deve ser não vazio e ter até 100 caracteres.")
            note.title = title
        if content is not None:
            if len(content) > 500:
                raise ValueError("O conteúdo deve ter até 500 caracteres.")
            note.content = content
        if category is not None:
            if category not in Note.VALID_CATEGORIES:
                raise ValueError("Categoria inválida. Use: Trabalho, Pessoal, Estudos, Histórias ou Projetos Futuros.")
            note.category = category

    def delete_note(self, note_id):
        note = self._find_note(note_id)
        if not note:
            raise ValueError("Nota não encontrada.")
        self.notes.remove(note)
        for n in self.notes:
            if n.related_note_id == note_id:
                n.related_note_id = None

    def connect_note(self, note_id, related_note_id):
        note = self._find_note(note_id)
        related_note = self._find_note(related_note_id)
        if not note or not related_note:
            raise ValueError("Uma das notas não foi encontrada.")
        if note_id == related_note_id:
            raise ValueError("Uma nota não pode ser conectada a si mesma.")
        note.related_note_id = related_note_id

    def _find_note(self, note_id):
        for note in self.notes:
            if note.id == note_id:
                return note
        return None