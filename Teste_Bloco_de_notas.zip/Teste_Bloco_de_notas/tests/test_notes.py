import pytest
from src.notes import NotesApp, Note

@pytest.fixture
def notes_app():
    return NotesApp()

def test_create_note_valid(notes_app):
    note_id = notes_app.create_note("Reunião", "Planejar sprint", "Trabalho")
    assert len(notes_app.notes) == 1
    assert notes_app.notes[0].title == "Reunião"
    assert notes_app.notes[0].content == "Planejar sprint"
    assert notes_app.notes[0].category == "Trabalho"

def test_create_note_empty_title(notes_app):
    with pytest.raises(ValueError, match="O título deve ser não vazio e ter até 100 caracteres."):
        notes_app.create_note("", "Conteúdo", "Pessoal")

def test_create_note_long_title(notes_app):
    long_title = "A" * 101
    with pytest.raises(ValueError, match="O título deve ser não vazio e ter até 100 caracteres."):
        notes_app.create_note(long_title, "Conteúdo", "Pessoal")

def test_create_note_invalid_category(notes_app):
    with pytest.raises(ValueError, match="Categoria inválida. Use: Trabalho, Pessoal, Estudos, Histórias ou Projetos Futuros."):
        notes_app.create_note("Título", "Conteúdo", "Lazer")

def test_create_note_long_content(notes_app):
    long_content = "A" * 501
    with pytest.raises(ValueError, match="O conteúdo deve ter até 500 caracteres."):
        notes_app.create_note("Título", long_content, "Estudos")

def test_list_notes(notes_app):
    notes_app.create_note("Nota 1", "Conteúdo 1", "Pessoal")
    notes_app.create_note("Nota 2", "Conteúdo 2", "Trabalho")
    assert len(notes_app.list_notes()) == 2

def test_edit_note_valid(notes_app):
    note_id = notes_app.create_note("Título Antigo", "Conteúdo Antigo", "Pessoal")
    notes_app.edit_note(note_id, title="Título Novo", content="Conteúdo Novo", category="Projetos Futuros")
    note = notes_app.notes[0]
    assert note.title == "Título Novo"
    assert note.content == "Conteúdo Novo"
    assert note.category == "Projetos Futuros"

def test_edit_note_not_found(notes_app):
    with pytest.raises(ValueError, match="Nota não encontrada."):
        notes_app.edit_note("id_inexistente", title="Novo Título")

def test_delete_note_valid(notes_app):
    note_id = notes_app.create_note("Título", "Conteúdo", "Trabalho")
    notes_app.delete_note(note_id)
    assert len(notes_app.notes) == 0

def test_delete_note_not_found(notes_app):
    with pytest.raises(ValueError, match="Nota não encontrada."):
        notes_app.delete_note("id_inexistente")

def test_connect_note_valid(notes_app):
    note_id1 = notes_app.create_note("História", "Esboço de uma história", "Histórias")
    note_id2 = notes_app.create_note("Planejamento", "Ideias para projeto", "Projetos Futuros")
    notes_app.connect_note(note_id1, note_id2)
    note1 = notes_app._find_note(note_id1)
    assert note1.related_note_id == note_id2

def test_connect_note_not_found(notes_app):
    note_id = notes_app.create_note("Título", "Conteúdo", "Trabalho")
    with pytest.raises(ValueError, match="Uma das notas não foi encontrada."):
        notes_app.connect_note(note_id, "id_inexistente")

def test_connect_note_to_itself(notes_app):
    note_id = notes_app.create_note("Título", "Conteúdo", "Trabalho")
    with pytest.raises(ValueError, match="Uma nota não pode ser conectada a si mesma."):
        notes_app.connect_note(note_id, note_id)

def test_delete_note_removes_relation(notes_app):
    note_id1 = notes_app.create_note("História", "Esboço de uma história", "Histórias")
    note_id2 = notes_app.create_note("Planejamento", "Ideias para projeto", "Projetos Futuros")
    notes_app.connect_note(note_id1, note_id2)
    notes_app.delete_note(note_id2)
    note1 = notes_app._find_note(note_id1)
    assert note1.related_note_id is None